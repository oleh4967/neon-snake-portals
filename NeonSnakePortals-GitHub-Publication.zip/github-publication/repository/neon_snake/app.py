import argparse
import time
import pygame as pg
from .settings import *
from .levels import LEVELS, validate_levels
from .logic import Campaign
from .saves import Store, DEFAULTS
from .input import Pads
from .audio import Audio
from .ui import View

KEYS = {pg.K_UP:"up", pg.K_w:"up", pg.K_DOWN:"down", pg.K_s:"down", pg.K_LEFT:"left",
        pg.K_a:"left", pg.K_RIGHT:"right", pg.K_d:"right", pg.K_RETURN:"a", pg.K_KP_ENTER:"a", pg.K_ESCAPE:"b",
        pg.K_SPACE:"start", pg.K_p:"start", pg.K_r:"x"}
DISCONNECTED = "Геймпад отключён. Подключите его снова или продолжите с клавиатуры"

class App:
    def __init__(self, save=None):
        pg.display.init()
        pg.font.init()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT), pg.SCALED)
        pg.display.set_caption("Neon Snake: Portals")
        self.view = View(self.screen)
        self.store = Store(save)
        self.settings = self.store.data
        self.audio = Audio(self.settings)
        self.pads = Pads(self.settings)
        self.campaign = Campaign()
        self.state, self.selected, self.source = "main", 0, "keyboard"
        self.running, self.focused = True, True
        self.return_state = "main"
        self.message = self.store.warning
        self.mapping_actions = ["up", "down", "left", "right", "a", "b", "x", "start", "axis_x", "axis_y"]
        self.mapping_index = 0
        self.mapping_wait = None
        self.mapping_draft = {}
        self.changed = 0

    @property
    def game(self):
        return self.campaign.game

    def switch(self, state):
        self.state, self.selected = state, 0
        self.game.clear_input()
        self.pads.reset()
        self.changed += 1

    def pause(self, message=""):
        self.game.set_paused(True)
        self.message = message
        self.switch("pause")

    def resume(self):
        self.game.set_paused(False)
        self.message = ""
        self.switch("playing")

    def begin(self, index=0):
        self.campaign = Campaign(index)
        self.message = ""
        self.switch("ready")

    def options(self):
        s = self.state
        if s == "main": return ["Start campaign", "Level select", "How to play", "Settings", "Quit"]
        if s == "ready": return ["Enter arena", "Main menu"]
        if s == "tutorial": return ["Back"]
        if s == "pause": return ["Resume", "Settings", "Main menu"]
        if s == "dead": return ["Retry level", "Main menu"]
        if s == "results": return ["Final results" if self.game.index == 4 else "Next level", "Main menu"]
        if s == "victory": return ["New campaign", "Main menu"]
        if s == "levels": return [f"{i+1}. {l.name}" if i < self.settings["unlocked"] else f"{i+1}. Locked" for i,l in enumerate(LEVELS)] + ["Back"]
        if s == "mapping": return ["Cancel"]
        if s == "settings":
            return [f"Volume     <  {self.settings['volume']:.0%}  >", f"Sound     {'OFF' if self.settings['muted'] else 'ON'}",
                    f"Reduced effects     {'ON' if self.settings['reduced_effects'] else 'OFF'}",
                    f"Movement     <  {self.settings['control_mode']}  >", f"Stick dead zone     <  {self.settings['deadzone']:.2f}  >",
                    "Controller: " + self.pads.label, "Assign fallback controls", "Restore control defaults", "Back"]
        return []

    def adjust(self, delta):
        i = self.selected
        if i == 0: self.settings["volume"] = round(max(0, min(1, self.settings["volume"]+delta*.05)), 2)
        elif i == 1: self.settings["muted"] = not self.settings["muted"]
        elif i == 2:
            self.settings["reduced_effects"] = not self.settings["reduced_effects"]
            self.view.effects.particles.clear()
        elif i == 3:
            modes = ["D-pad", "Left stick", "Both"]
            self.settings["control_mode"] = modes[(modes.index(self.settings["control_mode"])+delta)%3]
        elif i == 4: self.settings["deadzone"] = round(max(.1, min(.75, self.settings["deadzone"]+delta*.05)), 2)
        elif i == 5: self.pads.select(delta)
        self.store.write()

    def activate(self):
        s, i = self.state, self.selected
        if s == "main":
            if i == 0: self.begin()
            elif i == 1: self.switch("levels")
            elif i == 2: self.switch("tutorial")
            elif i == 3:
                self.return_state = "main"
                self.message = ""
                self.switch("settings")
            else: self.running = False
        elif s == "ready":
            if i == 0: self.resume()
            else: self.switch("main")
        elif s == "tutorial": self.switch("main")
        elif s == "levels":
            if i == 5: self.switch("main")
            elif i < self.settings["unlocked"]: self.begin(i)
        elif s == "pause":
            if i == 0: self.resume()
            elif i == 1:
                self.return_state = "pause"
                self.message = ""
                self.switch("settings")
            else: self.switch("main")
        elif s == "dead":
            if i == 0:
                self.campaign.retry()
                self.switch("ready")
            else: self.switch("main")
        elif s == "results":
            if i == 0:
                self.campaign.next_level()
                self.switch("victory" if self.campaign.won else "ready")
            else: self.switch("main")
        elif s == "victory":
            if i == 0: self.begin()
            else: self.switch("main")
        elif s == "settings":
            if i <= 5: self.adjust(1)
            elif i == 6:
                if not self.pads.device: self.message = "Connect a controller first."
                elif self.pads.device["ctrl"]: self.message = "SDL standard mapping is active. No assignment needed."
                else:
                    self.mapping_index, self.mapping_wait, self.mapping_draft = 0, None, {}
                    self.switch("mapping")
            elif i == 7:
                for key in ("deadzone", "control_mode", "active_guid", "bindings"):
                    self.settings[key] = {} if key == "bindings" else DEFAULTS[key]
                self.pads.reset()
                self.store.write()
                self.message = "Control defaults restored. Unmapped pads require assignment."
            else:
                self.store.write()
                self.message = ""
                self.switch(self.return_state)
        elif s == "mapping": self.switch("settings")

    def action(self, action):
        if self.state == "playing":
            if action in DIRECTIONS: self.game.queue(DIRECTIONS[action])
            elif action in ("b", "start"): self.pause()
            return
        if action == "b":
            if self.state == "pause": self.resume()
            elif self.state == "settings":
                self.store.write()
                self.message = ""
                self.switch(self.return_state)
            elif self.state == "mapping": self.switch("settings")
            elif self.state != "main": self.switch("main")
        elif action == "start" and self.state == "pause": self.resume()
        elif action == "x" and self.state == "dead":
            self.campaign.retry()
            self.switch("ready")
        elif action == "a": self.activate()
        elif action in ("up", "down"):
            self.selected = (self.selected + (1 if action == "down" else -1)) % len(self.options())
        elif action in ("left", "right") and self.state == "settings":
            self.adjust(1 if action == "right" else -1)

    def mapping_event(self, event):
        if self.mapping_wait:
            return
        if not self.pads.device:
            self.message = "Controller disconnected. Reconnect, then assign again."
            self.switch("settings")
            return
        action = self.mapping_actions[self.mapping_index]
        spec = self.pads.capture(event, action)
        if spec:
            # Reject accidentally assigning two required actions to the same input.
            if spec in self.mapping_draft.values():
                return
            self.mapping_draft[action] = spec
            self.mapping_wait = spec

    def events(self):
        events = pg.event.get()
        transitioned = False
        for e in events:
            if e.type == pg.QUIT: self.running = False
            elif e.type in (pg.JOYDEVICEADDED, pg.JOYDEVICEREMOVED, pg.CONTROLLERDEVICEADDED, pg.CONTROLLERDEVICEREMOVED):
                lost = self.pads.refresh()
                self.game.clear_input()
                if lost:
                    if self.state == "playing": self.pause(DISCONNECTED)
                # Hotplug changes must not feed held inputs into a new screen.
                transitioned = True
            elif e.type == pg.WINDOWFOCUSLOST:
                self.focused = False
                self.pads.reset()
                if self.state == "playing": self.pause("Window focus lost. Resume when ready.")
                transitioned = True
            elif e.type == pg.WINDOWFOCUSGAINED:
                self.focused = True
                self.pads.reset()
            elif not transitioned and self.focused:
                before = self.changed
                if e.type == pg.KEYDOWN and not getattr(e, "repeat", False):
                    self.source = "keyboard"
                    if e.key in KEYS: self.action(KEYS[e.key])
                elif e.type == pg.MOUSEMOTION and self.state != "playing":
                    if e.rel != (0, 0):
                        self.source = "keyboard"
                        for i, rect in enumerate(self.view.buttons):
                            if rect.collidepoint(e.pos): self.selected = i
                elif e.type == pg.MOUSEBUTTONDOWN and e.button == 1 and self.state != "playing":
                    self.source = "keyboard"
                    for i, rect in enumerate(self.view.buttons):
                        if rect.collidepoint(e.pos):
                            self.selected = i
                            self.activate()
                            break
                elif self.state == "mapping": self.mapping_event(e)
                transitioned = self.changed != before
        if self.state == "mapping":
            if self.mapping_wait and self.pads.device and not self.pads.spec_value(self.mapping_wait):
                self.mapping_wait = None
                self.mapping_index += 1
                if self.mapping_index == len(self.mapping_actions):
                    self.settings["bindings"][self.pads.device["guid"]] = self.mapping_draft
                    self.store.write()
                    self.message = "Custom controls saved."
                    self.switch("settings")
            return
        if not transitioned and self.focused:
            for action in self.pads.poll(time.monotonic(), self.state != "playing"):
                self.source = "pad"
                before = self.changed
                self.action(action)
                if before != self.changed: break

    def update(self, dt):
        if self.state != "playing": return
        self.game.update(dt)
        self.settings["high_score"] = max(self.settings["high_score"], self.game.score)
        self.view.effects.update(min(dt, .1))
        played = set()
        for name, cell in self.game.events:
            if name not in played:
                self.audio.play(name)
                played.add(name)
            self.view.effects.burst(cell, GOLD if name == "gold" else PORTAL_COLORS[0] if name == "portal" else CYAN, self.settings["reduced_effects"])
        self.game.events.clear()
        if self.game.state != "playing":
            self.settings["high_score"] = max(self.settings["high_score"], self.game.score)
            if self.game.state == "complete":
                self.settings["unlocked"] = max(self.settings["unlocked"], min(5, self.game.index+2))
            self.store.write()
            self.switch("results" if self.game.state == "complete" else "dead")

    def draw(self):
        pad = self.source == "pad"
        hint = "D-pad / LS  Select     A  Confirm     B  Back" if pad else "Arrows / WASD  Select     Enter  Confirm     Esc  Back"
        t = pg.time.get_ticks()/1000
        if self.state == "playing":
            self.view.buttons = []
            self.view.game(self.game, self.settings["high_score"], t, self.settings["reduced_effects"],
                           "D-pad / LS  Steer     Start / B  Pause" if pad else "Arrows / WASD  Steer     Space / P / Esc  Pause")
            return
        g, s = self.game, self.state
        title, subtitle, lines = "", "", []
        if s == "main":
            title, subtitle = "NEON SNAKE", "P O R T A L S   /   A FIVE-ARENA CAMPAIGN"
            lines = ["Collect energy. Read the exits. Keep moving.", f"PERSONAL BEST   {self.settings['high_score']:04}    /    ARENAS UNLOCKED   {self.settings['unlocked']}/5"]
        elif s == "tutorial":
            title, subtitle = "Read the arena", "ONE GRID. EVERY TURN COUNTS."
            lines = ["Steer with arrows / WASD, D-pad or the left stick.", "Collect cyan spheres (+10) to reach each arena's goal.",
                     "Gold diamonds (+50) expire in 8 seconds. Both grow your snake.", "Portals A / B preserve your direction. Follow the exit arrow.",
                     "Walls, blocks and your body are fatal. Avoid occupied exits.", "Space / P / Start pauses. R / X retries after a crash.",
                     "Each new arena resets length. Retry restores its starting score."]
        elif s == "ready":
            title, subtitle = g.level.name, f"ARENA {g.index+1:02} / 05    //    READY WHEN YOU ARE"
            lines = [f"Collect {g.level.goal} ordinary spheres. Starting speed: {g.speed:.1f} cells/s.",
                     "Open field. Learn to turn early." if not g.level.pairs else f"{len(g.level.pairs)} portal pair(s). Exit direction stays the same.",
                     f"Campaign score: {g.start_score}  /  Starting length: 4"]
        elif s == "pause":
            title, subtitle = "Signal paused", "MOVEMENT AND BONUS TIMERS ARE FROZEN"
            lines = [self.message or "Take a breath. The arena will wait.", f"{g.level.name}   /   Score {g.score}   /   Energy {g.collected}/{g.level.goal}"]
        elif s == "dead":
            title, subtitle = "Signal lost", "COLLISION  //  " + g.reason.upper()
            lines = [f"Score {g.score}    /    Best {self.settings['high_score']}", f"Retry returns your score to {g.start_score}.", "X  Retry level" if pad else "R  Retry level"]
        elif s == "results":
            title, subtitle = "Arena secured", g.level.name.upper() + "  //  COMPLETE"
            lines = [f"Campaign score   {g.score}    /    Level earned   {g.score-g.start_score}",
                     f"Energy {g.collected}/{g.level.goal}    /    Gold {g.gold_collected}    /    Time {g.elapsed:.1f}s",
                     "Next arena starts with a fresh snake and your campaign score."]
        elif s == "victory":
            title, subtitle = "CORE STABILIZED", "ALL FIVE ARENAS COMPLETE"
            lines = [f"Final score   {g.score}    /    Best   {self.settings['high_score']}",
                     f"Gold collected   {self.campaign.total_gold}    /    Time   {self.campaign.total_time:.1f}s",
                     "Your record and unlocked arenas have been saved." if not self.store.warning else self.store.warning]
        elif s == "levels": title, subtitle = "Choose an arena", "NEW RUNS START AT ZERO SCORE"
        elif s == "settings":
            title, subtitle = "System settings", self.message or "LEFT / RIGHT TO ADJUST   //   CHANGES SAVE AUTOMATICALLY"
        elif s == "mapping":
            action = self.mapping_actions[self.mapping_index]
            title, subtitle = "Assign controls", f"{self.mapping_index+1} / 10  //  {action.upper()}"
            instruction = "Push the LEFT stick fully " + ("RIGHT" if action == "axis_x" else "DOWN") if action.startswith("axis_") else "Press " + {"a":"A (bottom face button)", "b":"B (right face button)", "x":"X (left face button)", "start":"Start / Menu"}.get(action, "D-pad " + action.upper())
            lines = ["Release the assigned control." if self.mapping_wait else instruction,
                     "Use only game controls. Do not assign Home or Turbo.", "Move one control at a time, then release it. Esc cancels."]
        if s == "settings": hint = "D-pad / LS  Select     Left / Right  Adjust     B  Back" if pad else "Up / Down  Select     Left / Right / Click  Adjust     Esc  Back"
        self.view.menu(title, subtitle, lines, self.options(), self.selected, hint, t, s == "settings")
        if self.store.warning:
            self.view.text(self.store.warning, (500, 758), 14, GOLD, True, 920)

    def run(self, frames=0, screenshot=None):
        clock = pg.time.Clock()
        n = 0
        while self.running:
            dt = clock.tick(FPS)/1000
            self.events()
            self.update(dt)
            self.draw()
            pg.display.flip()
            n += 1
            if frames and n >= frames: break
        if screenshot:
            pg.image.save(self.screen, screenshot)
        self.settings["high_score"] = max(self.settings["high_score"], self.game.score)
        self.store.write()
        pg.quit()

def main():
    parser = argparse.ArgumentParser(description="Neon Snake: Portals")
    parser.add_argument("--frames", type=int, default=0, help="Exit after N rendered frames (smoke test)")
    parser.add_argument("--screenshot", help="Save the final rendered frame")
    parser.add_argument("--save", help="Override user save path for isolated testing")
    parser.add_argument("--showcase", action="store_true", help="Show a paused portal arena for visual QA")
    parser.add_argument("--font-check", action="store_true", help="Show the required Cyrillic disconnect message")
    args = parser.parse_args()
    validate_levels()
    app = App(args.save)
    if args.showcase:
        app.begin(3)
        app.game.body = [(5,4),(4,4),(3,4),(2,4)]
        app.game.links = [True]*3
        app.game.food = (16,4)
        app.game.gold, app.game.gold_left = (18,15), 6.5
        app.state = "playing"
        app.game.set_paused(True)
    if args.font_check: app.pause(DISCONNECTED)
    app.run(args.frames, args.screenshot)
