import math
import random
import pygame as pg
from .settings import *

def center(cell):
    return BOARD_X + cell[0]*CELL + CELL//2, BOARD_Y + cell[1]*CELL + CELL//2

class Effects:
    def __init__(self):
        self.cache = {}
        self.particles = []
        self.rng = random.Random()

    def glow(self, surface, pos, color, radius):
        key = (color, radius)
        if key not in self.cache:
            s = pg.Surface((radius*6, radius*6), pg.SRCALPHA)
            for r in range(radius*3, 0, -2):
                alpha = int(22*(1-r/(radius*3))**1.5)
                pg.draw.circle(s, (*color, alpha), (radius*3, radius*3), r)
            self.cache[key] = s
        s = self.cache[key]
        surface.blit(s, (int(pos[0]-s.get_width()/2), int(pos[1]-s.get_height()/2)))

    def burst(self, cell, color, reduced):
        if reduced:
            return
        x, y = center(cell)
        for _ in range(12):
            a, v = self.rng.random()*math.tau, self.rng.uniform(30, 100)
            self.particles.append([x, y, math.cos(a)*v, math.sin(a)*v, .45, color])
        self.particles = self.particles[-180:]

    def update(self, dt):
        for p in self.particles:
            p[0] += p[2]*dt
            p[1] += p[3]*dt
            p[4] -= dt
        self.particles = [p for p in self.particles if p[4] > 0]

    def draw(self, surface):
        for x, y, vx, vy, life, color in self.particles:
            pg.draw.circle(surface, color, (int(x), int(y)), max(1, int(life*6)))
