"""Windows Unicode Shell Link creation without WScript or external tools."""
import ctypes as ct
from pathlib import Path
import uuid

def create_shortcut(executable, directory=None):
    if not hasattr(ct, "WinDLL"):
        raise OSError("Desktop shortcuts are available on Windows only")
    executable = Path(executable).resolve(strict=True)
    ole = ct.WinDLL("ole32")
    HRESULT = ct.c_long
    pointer = ct.c_void_p
    guid_type = ct.c_ubyte * 16

    def guid(value):
        return guid_type.from_buffer_copy(uuid.UUID(value).bytes_le)

    def check(result):
        if result < 0:
            raise OSError(f"Windows Shell Link failed: HRESULT 0x{result & 0xffffffff:08X}")

    def method(obj, index, result, *arguments):
        table = ct.cast(obj, ct.POINTER(ct.POINTER(pointer))).contents
        return ct.WINFUNCTYPE(result, pointer, *arguments)(table[index])

    ole.CoInitializeEx.argtypes = [pointer, ct.c_ulong]
    ole.CoInitializeEx.restype = HRESULT
    initialized = ole.CoInitializeEx(None, 2)
    check(initialized)
    link, persist = pointer(), pointer()
    try:
        if directory is None:
            buffer = ct.create_unicode_buffer(32768)
            shell = ct.WinDLL("shell32")
            shell.SHGetFolderPathW.argtypes = [pointer, ct.c_int, pointer, ct.c_ulong, ct.c_wchar_p]
            shell.SHGetFolderPathW.restype = HRESULT
            check(shell.SHGetFolderPathW(None, 0x10, None, 0, buffer))
            directory = buffer.value
        target = Path(directory).resolve(strict=True)/"Neon Snake Portals.lnk"
        clsid = guid("00021401-0000-0000-c000-000000000046")
        iid_link = guid("000214f9-0000-0000-c000-000000000046")
        ole.CoCreateInstance.argtypes = [pointer, pointer, ct.c_ulong, pointer, ct.POINTER(pointer)]
        ole.CoCreateInstance.restype = HRESULT
        check(ole.CoCreateInstance(ct.byref(clsid), None, 1, ct.byref(iid_link), ct.byref(link)))
        # IUnknown slots 0..2 precede the documented IShellLinkW methods.
        check(method(link, 20, HRESULT, ct.c_wchar_p)(link, str(executable)))
        check(method(link, 9, HRESULT, ct.c_wchar_p)(link, str(executable.parent)))
        check(method(link, 7, HRESULT, ct.c_wchar_p)(link, "Neon Snake: Portals"))
        check(method(link, 17, HRESULT, ct.c_wchar_p, ct.c_int)(link, str(executable), 0))
        iid_file = guid("0000010b-0000-0000-c000-000000000046")
        check(method(link, 0, HRESULT, pointer, ct.POINTER(pointer))(link, ct.byref(iid_file), ct.byref(persist)))
        check(method(persist, 6, HRESULT, ct.c_wchar_p, ct.c_int)(persist, str(target), 1))
        return target
    finally:
        if persist:
            method(persist, 2, ct.c_ulong)(persist)
        if link:
            method(link, 2, ct.c_ulong)(link)
        ole.CoUninitialize()
