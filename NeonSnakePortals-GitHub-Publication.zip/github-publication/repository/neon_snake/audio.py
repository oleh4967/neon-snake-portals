"""Original synthesized PCM tones; no external sound assets."""
from array import array
import math
import pygame as pg

class Audio:
    def __init__(self, settings):
        self.settings, self.sounds = settings, {}
        try:
            pg.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
            for name, frequency, length in (("food", 740, .09), ("gold", 1150, .18),
                    ("portal", 420, .16), ("death", 130, .3), ("complete", 880, .35)):
                samples = array("h")
                for i in range(int(22050*length)):
                    t = i/22050
                    envelope = min(1, t/.008) * (1-t/length)**2
                    tone = math.sin(2*math.pi*(frequency*t + frequency*.6*t*t))
                    samples.append(int(11000*tone*envelope))
                self.sounds[name] = pg.mixer.Sound(buffer=samples)
        except (pg.error, OSError):
            self.sounds = {}

    def play(self, name):
        if not self.settings["muted"] and name in self.sounds:
            self.sounds[name].set_volume(self.settings["volume"])
            self.sounds[name].play()
