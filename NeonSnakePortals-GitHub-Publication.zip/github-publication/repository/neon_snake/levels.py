from dataclasses import dataclass
from .settings import COLS, ROWS

@dataclass(frozen=True)
class Level:
    name: str
    goal: int
    speed: float
    obstacles: frozenset = frozenset()
    pairs: tuple = ()
    start: tuple = ((7, 10), (6, 10), (5, 10), (4, 10))

    @property
    def portals(self):
        return {p: q for a, b in self.pairs for p, q in ((a, b), (b, a))}

def line(x, y, length, vertical=False):
    return {(x + (0 if vertical else i), y + (i if vertical else 0)) for i in range(length)}

LEVELS = (
    Level("Awakening", 5, 7.0),
    Level("First crossing", 6, 7.5, pairs=(((8, 5), (22, 14)),)),
    Level("Contours", 7, 8.0,
          frozenset(line(13, 3, 5, True) | line(16, 12, 5, True) | line(5, 15, 5)),
          (((7, 5), (23, 14)),)),
    Level("Interweave", 8, 8.5,
          frozenset(line(12, 3, 5, True) | line(17, 12, 5, True) | line(12, 9, 6)),
          (((6, 4), (23, 15)), ((23, 4), (6, 15)))),
    Level("Neon core", 10, 9.0,
          frozenset(line(10, 3, 5, True) | line(19, 12, 5, True) |
                    line(14, 5, 5) | line(11, 14, 5) | line(14, 9, 3)),
          (((5, 4), (24, 15)), ((24, 4), (5, 15)))),
)

def validate_levels():
    for level in LEVELS:
        portals = level.portals
        assert len(portals) == len(level.pairs) * 2
        assert not (set(portals) & level.obstacles)
        assert not (set(level.start) & (set(portals) | level.obstacles))
        for x, y in portals:
            assert 2 <= x < COLS - 2 and 2 <= y < ROWS - 2
            # Leave two cells of static clearance in all four exit directions.
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                assert all((x + dx*k, y + dy*k) not in level.obstacles for k in (1, 2))
