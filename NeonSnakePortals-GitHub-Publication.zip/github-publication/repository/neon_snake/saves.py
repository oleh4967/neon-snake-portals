import json
import math
import os
from pathlib import Path
import tempfile

DEFAULTS = dict(high_score=0, unlocked=1, volume=0.55, muted=False,
                reduced_effects=False, deadzone=0.25, control_mode="Both",
                active_guid="", bindings={})

def save_path():
    root = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("XDG_DATA_HOME") or Path.home()/".local"/"share")
    return root / "NeonSnakePortals" / "save.json"

def clean(data):
    result = DEFAULTS.copy()
    result["bindings"] = {}
    if not isinstance(data, dict):
        return result
    for key, lo, hi in (("high_score", 0, 10**9), ("unlocked", 1, 5)):
        v = data.get(key)
        if type(v) is int:
            result[key] = max(lo, min(hi, v))
    for key, lo, hi in (("volume", 0, 1), ("deadzone", 0.1, 0.75)):
        v = data.get(key)
        if type(v) in (int, float) and math.isfinite(v):
            result[key] = max(lo, min(hi, v))
    for key in ("muted", "reduced_effects"):
        if type(data.get(key)) is bool:
            result[key] = data[key]
    if data.get("control_mode") in ("D-pad", "Left stick", "Both"):
        result["control_mode"] = data["control_mode"]
    if isinstance(data.get("active_guid"), str):
        result["active_guid"] = data["active_guid"][:128]
    bindings = data.get("bindings", {})
    if isinstance(bindings, dict):
        for guid, mapping in list(bindings.items())[:32]:
            if not isinstance(guid, str) or not isinstance(mapping, dict):
                continue
            valid = {}
            for action, spec in mapping.items():
                if action not in ("up", "down", "left", "right", "a", "b", "x", "start", "axis_x", "axis_y"):
                    continue
                if (isinstance(spec, list) and len(spec) == 3 and spec[0] in ("button", "hat", "axis")
                    and type(spec[1]) is int and 0 <= spec[1] < 128 and type(spec[2]) is int
                    and spec[2] in (-2, -1, 1, 2)):
                    valid[action] = spec
            result["bindings"][guid[:128]] = valid
    return result

class Store:
    def __init__(self, path=None):
        self.path = Path(path) if path else save_path()
        self.warning = ""
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            data = {}
        except (ValueError, OSError):
            data = {}
            self.warning = "Save could not be read. Defaults restored."
        self.data = clean(data)
        self.write()

    def write(self):
        tmp = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.path.parent,
                                             prefix="save-", suffix=".tmp", delete=False) as f:
                tmp = f.name
                json.dump(clean(self.data), f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
            return True
        except OSError:
            self.warning = "Save unavailable. Progress is kept for this session."
            return False
        finally:
            if tmp and os.path.exists(tmp):
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
