"""Controller polling is the single source of pad actions (never JOY + SDL twice)."""
from .settings import DIRECTIONS

class StickFilter:
    def __init__(self):
        self.direction = None
        self.axis = None

    def read(self, x, y, deadzone):
        magnitude = max(abs(x), abs(y))
        threshold = deadzone * 0.72 if self.direction else deadzone
        if magnitude < threshold:
            self.direction = None
            return None
        if abs(abs(x)-abs(y)) > 0.08:
            self.axis = "x" if abs(x) > abs(y) else "y"
        elif self.axis is None:
            self.axis = "x"
        self.direction = ("right" if x > 0 else "left") if self.axis == "x" else ("down" if y > 0 else "up")
        return self.direction

class PadEdges:
    def __init__(self):
        self.previous_buttons = set()
        self.previous_direction = None
        self.repeat_at = 0.0
        self.armed = False

    def update(self, direction, buttons, neutral, now, menu):
        if not self.armed:
            if neutral:
                self.armed = True
            self.previous_buttons = set(buttons)
            self.previous_direction = direction
            return []
        actions = sorted(set(buttons) - self.previous_buttons)
        self.previous_buttons = set(buttons)
        if direction != self.previous_direction:
            if direction:
                actions.append(direction)
            self.repeat_at = now + 0.35
        elif direction and menu and now >= self.repeat_at:
            actions.append(direction)
            self.repeat_at = now + 0.15
        self.previous_direction = direction
        return actions

class Pads:
    def __init__(self, settings):
        import pygame as pg
        self.pg, self.settings = pg, settings
        pg.joystick.init()
        try:
            from pygame._sdl2 import controller
            controller.init()
            self.sdl = controller
        except (ImportError, pg.error):
            self.sdl = None
        self.devices = {}
        self.active = None
        self.filter, self.edges = StickFilter(), PadEdges()
        self.refresh()

    def reset(self):
        self.filter, self.edges = StickFilter(), PadEdges()

    def refresh(self):
        old = self.active
        found = set()
        for index in range(self.pg.joystick.get_count()):
            try:
                joy = self.pg.joystick.Joystick(index)
                ident = joy.get_instance_id()
                found.add(ident)
                if ident in self.devices:
                    continue
                ctrl = None
                if self.sdl and self.sdl.is_controller(index):
                    try:
                        ctrl = self.sdl.Controller(index)
                    except self.pg.error:
                        pass
                self.devices[ident] = dict(joy=joy, ctrl=ctrl, guid=joy.get_guid(), name=joy.get_name())
            except self.pg.error:
                continue
        for ident in list(self.devices):
            if ident not in found:
                dev = self.devices.pop(ident)
                if dev["ctrl"]:
                    dev["ctrl"].quit()
                dev["joy"].quit()
        lost = old is not None and old not in self.devices
        if self.active not in self.devices:
            preferred = self.settings["active_guid"]
            self.active = next((i for i, d in self.devices.items() if d["guid"] == preferred), next(iter(self.devices), None))
            self.reset()
        return lost

    @property
    def device(self):
        return self.devices.get(self.active)

    @property
    def label(self):
        d = self.device
        if not d:
            return "No controller connected"
        index = list(self.devices).index(self.active)+1
        return f"[{index}/{len(self.devices)}] " + d["name"] + (" / SDL" if d["ctrl"] else " / custom mapping")

    def select(self, delta):
        ids = list(self.devices)
        if ids:
            self.active = ids[(ids.index(self.active) + delta) % len(ids)]
            self.settings["active_guid"] = self.device["guid"]
            self.reset()

    def spec_value(self, spec):
        joy = self.device["joy"]
        kind, index, sign = spec
        try:
            if kind == "button":
                return bool(joy.get_button(index))
            if kind == "hat":
                x, y = joy.get_hat(index)
                return {1: y > 0, -1: y < 0, 2: x > 0, -2: x < 0}[sign]
            return joy.get_axis(index) * sign > 0.55
        except (self.pg.error, IndexError):
            return False

    def poll(self, now, menu):
        dev = self.device
        if not dev:
            return []
        pg, joy, ctrl = self.pg, dev["joy"], dev["ctrl"]
        try:
            if ctrl:
                buttons = {name for name, code in (("a", pg.CONTROLLER_BUTTON_A), ("b", pg.CONTROLLER_BUTTON_B),
                            ("x", pg.CONTROLLER_BUTTON_X), ("start", pg.CONTROLLER_BUTTON_START)) if ctrl.get_button(code)}
                dpad = next((name for name, code in (("up", pg.CONTROLLER_BUTTON_DPAD_UP),
                         ("down", pg.CONTROLLER_BUTTON_DPAD_DOWN), ("left", pg.CONTROLLER_BUTTON_DPAD_LEFT),
                         ("right", pg.CONTROLLER_BUTTON_DPAD_RIGHT)) if ctrl.get_button(code)), None)
                x = ctrl.get_axis(pg.CONTROLLER_AXIS_LEFTX) / 32768
                y = ctrl.get_axis(pg.CONTROLLER_AXIS_LEFTY) / 32768
            else:
                mapping = self.settings["bindings"].get(dev["guid"], {})
                buttons = {name for name in ("a", "b", "x", "start") if name in mapping and self.spec_value(mapping[name])}
                dpad = next((name for name in DIRECTIONS if name in mapping and self.spec_value(mapping[name])), None)
                def axis(name):
                    spec = mapping.get(name)
                    if not spec or spec[0] != "axis" or spec[1] >= joy.get_numaxes():
                        return 0.0
                    return joy.get_axis(spec[1]) * spec[2]
                x, y = axis("axis_x"), axis("axis_y")
            stick = self.filter.read(x, y, self.settings["deadzone"])
            mode = self.settings["control_mode"]
            direction = (dpad or stick) if menu or mode == "Both" else (dpad if mode == "D-pad" else stick)
            # All physical buttons must be released on reconnect / screen changes.
            neutral = not any(joy.get_button(i) for i in range(joy.get_numbuttons())) and not dpad and max(abs(x), abs(y)) < self.settings["deadzone"] * 0.72
            return self.edges.update(direction, buttons, neutral, now, menu)
        except pg.error:
            return []

    def capture(self, event, action):
        pg = self.pg
        if not self.device or getattr(event, "instance_id", None) != self.active:
            return None
        if action.startswith("axis_"):
            if event.type == pg.JOYAXISMOTION and abs(event.value) > 0.65:
                return ["axis", event.axis, 1 if event.value > 0 else -1]
        elif event.type == pg.JOYBUTTONDOWN:
            return ["button", event.button, 1]
        elif event.type == pg.JOYHATMOTION and event.value != (0, 0):
            x, y = event.value
            return ["hat", event.hat, (2 if x > 0 else -2) if x else (1 if y > 0 else -1)]
        elif event.type == pg.JOYAXISMOTION and abs(event.value) > 0.7:
            return ["axis", event.axis, 1 if event.value > 0 else -1]
        return None
