"""Pure rules. No pygame import, wall clock, filesystem or rendering."""
from collections import deque
import random
from .settings import *
from .levels import LEVELS

def add(a, b):
    return a[0] + b[0], a[1] + b[1]

class Game:
    def __init__(self, index=0, score=0, rng=None, level=None):
        self.index = index
        self.level = level or LEVELS[index]
        self.rng = rng or random.Random()
        self.start_score = self.score = score
        self.body = list(self.level.start)
        # links[i] connects body[i] and body[i+1]; portal edges never draw a line.
        self.links = [True] * (len(self.body) - 1)
        self.direction = RIGHT
        self.turns = deque()
        self.collected = self.gold_collected = 0
        self.elapsed = self.accumulator = 0.0
        self.gold = None
        self.gold_left = 0.0
        self.food = None
        self.state = "playing"
        self.reason = ""
        self.events = []
        self.paused = False
        self.spawn_food()

    @property
    def speed(self):
        return min(MAX_SPEED, self.level.speed + self.collected * 0.16)

    def queue(self, direction):
        previous = self.turns[-1] if self.turns else self.direction
        if (direction not in DIRECTIONS.values() or direction == previous or
                direction == (-previous[0], -previous[1]) or len(self.turns) >= TURN_BUFFER):
            return False
        self.turns.append(direction)
        return True

    def clear_input(self):
        self.turns.clear()
        self.accumulator = 0.0

    def set_paused(self, value):
        self.paused = value
        self.clear_input()

    def destination(self, direction=None):
        entry = add(self.body[0], direction or (self.turns[0] if self.turns else self.direction))
        return entry, self.level.portals.get(entry, entry)

    def collision(self, entry, target, growing):
        if not (0 <= target[0] < COLS and 0 <= target[1] < ROWS):
            return "Wall"
        if target in self.level.obstacles or entry in self.level.obstacles:
            return "Obstacle"
        occupied = self.body if growing else self.body[:-1]
        if target in occupied or entry in occupied:
            return "Own body"
        return ""

    def preview(self):
        entry, target = self.destination()
        if entry == target:
            return None
        growing = target == self.food or (self.gold is not None and target == self.gold)
        return target, bool(self.collision(entry, target, growing)), (self.turns[0] if self.turns else self.direction)

    def free_cells(self):
        blocked = set(self.body) | self.level.obstacles
        # Traverse the directed portal graph, reserving both existing foods.
        seen = {self.body[0]}
        todo = deque(seen)
        portals = self.level.portals
        while todo:
            pos = todo.popleft()
            for d in DIRECTIONS.values():
                entry = add(pos, d)
                target = portals.get(entry, entry)
                if (0 <= target[0] < COLS and 0 <= target[1] < ROWS and
                        entry not in blocked and target not in blocked and target not in seen):
                    seen.add(target)
                    todo.append(target)
        return sorted(seen - blocked - set(portals) - {self.food, self.gold})

    def spawn_food(self):
        cells = self.free_cells()
        if not cells:
            # Finite exhaustive search: a secured reachable arena is a level clear.
            self.state, self.reason = "complete", "Arena secured"
            return
        self.food = self.rng.choice(cells)

    def step(self):
        if self.paused or self.state != "playing":
            return
        if self.turns:
            self.direction = self.turns.popleft()
        entry, target = self.destination(self.direction)
        normal = target == self.food
        golden = self.gold is not None and target == self.gold
        growing = normal or golden
        # Resolve teleport once, then collision, then insert head/remove tail.
        # Excluding the departing tail is valid only on a non-growing step.
        self.reason = self.collision(entry, target, growing)
        if self.reason:
            self.state = "dead"
            self.events.append(("death", self.body[0]))
            return
        self.body.insert(0, target)
        self.links.insert(0, entry == target)
        if not growing:
            self.body.pop()
        self.links = self.links[:len(self.body)-1]
        if entry != target:
            self.events.extend((("portal", entry), ("portal", target)))
        if normal:
            self.score += 10
            self.collected += 1
            self.food = None
            self.events.append(("food", target))
        if golden:
            self.score += 50
            self.gold_collected += 1
            self.gold, self.gold_left = None, 0.0
            self.events.append(("gold", target))
        if self.collected >= self.level.goal:
            self.state = "complete"
        elif normal:
            self.spawn_food()
            if self.collected % GOLD_EVERY == 0 and self.gold is None:
                cells = self.free_cells()
                if cells:
                    self.gold, self.gold_left = self.rng.choice(cells), GOLD_SECONDS
        if self.state == "complete":
            self.events.append(("complete", target))

    def update(self, dt):
        if self.paused or self.state != "playing":
            return
        # Discard stalls rather than catch up an invisible chain of movements.
        dt = min(max(dt, 0.0), 0.1)
        self.elapsed += dt
        if self.gold is not None:
            self.gold_left = max(0.0, self.gold_left - dt)
            if self.gold_left == 0:
                self.gold = None
        self.accumulator += dt
        interval = 1 / self.speed
        if self.accumulator >= interval:
            self.accumulator %= interval
            self.step()

class Campaign:
    def __init__(self, index=0, rng=None):
        self.rng = rng or random.Random()
        self.game = Game(index, rng=self.rng)
        self.total_time = 0.0
        self.total_gold = 0
        self.won = False

    def retry(self):
        g = self.game
        self.game = Game(g.index, g.start_score, self.rng)

    def next_level(self):
        g = self.game
        if g.state != "complete":
            return
        self.total_time += g.elapsed
        self.total_gold += g.gold_collected
        if g.index == len(LEVELS)-1:
            self.won = True
        else:
            self.game = Game(g.index+1, g.score, self.rng)
