import math
import os
from pathlib import Path
import pygame as pg
from .settings import *
from .effects import center, Effects

class View:
    def __init__(self, screen):
        self.screen = screen
        # System fonts need no downloads. Segoe UI / DejaVu Sans include Cyrillic.
        # match_font('segoeui') can select Segoe UI Light on Windows.
        regular = Path(os.environ.get("WINDIR", "C:/Windows"))/"Fonts"/"segoeui.ttf"
        path = str(regular) if regular.is_file() else pg.font.match_font("dejavusans,arial")
        self.fonts = {s: pg.font.Font(path, s) for s in (14, 16, 18, 20, 24, 28, 36, 48, 64)}
        self.effects = Effects()
        self.background = pg.Surface((WIDTH, HEIGHT))
        self.background.fill(BG)
        for y in range(HEIGHT):
            pg.draw.line(self.background, (7, 12 + int(5*y/HEIGHT), 24 + int(8*y/HEIGHT)), (0, y), (WIDTH, y))
        self.grid = pg.Surface((COLS*CELL, ROWS*CELL))
        self.grid.fill((9, 19, 32))
        for x in range(0, COLS*CELL, CELL):
            pg.draw.line(self.grid, (17, 32, 47), (x, 0), (x, ROWS*CELL))
        for y in range(0, ROWS*CELL, CELL):
            pg.draw.line(self.grid, (17, 32, 47), (0, y), (COLS*CELL, y))
        self.buttons = []

    def text(self, text, pos, size=20, color=WHITE, center_align=False, max_width=None):
        font = self.fonts[size]
        if max_width:
            for s in sorted(self.fonts, reverse=True):
                if s <= size and self.fonts[s].size(str(text))[0] <= max_width:
                    font = self.fonts[s]
                    break
            while font.size(str(text))[0] > max_width and len(str(text)) > 3:
                text = str(text)[:-4] + "..."
        image = font.render(str(text), True, color)
        rect = image.get_rect(center=pos) if center_align else image.get_rect(topleft=pos)
        self.screen.blit(image, rect)
        return rect

    def base(self):
        self.screen.blit(self.background, (0, 0))
        self.text("N / P", (40, 26), 24, CYAN)
        self.text("NEON SNAKE   /   PORTALS", (130, 30), 16, MUTED)
        self.text("GRID SYSTEM  //  30 : 20", (740, 30), 14, MUTED)
        pg.draw.line(self.screen, (34, 52, 71), (40, 68), (960, 68))

    def ring(self, cell, color, label, t, reduced=False):
        x, y = center(cell)
        self.effects.glow(self.screen, (x, y), color, 16)
        pg.draw.circle(self.screen, (18, 20, 43), (x, y), 12)
        pg.draw.circle(self.screen, color, (x, y), 11, 2)
        angle = 0 if reduced else t*1.8
        r = pg.Rect(x-15, y-15, 30, 30)
        pg.draw.arc(self.screen, color, r, angle, angle+2.0, 2)
        pg.draw.arc(self.screen, color, r, angle+math.pi, angle+math.pi+2, 2)
        self.text(label, (x, y-1), 14, color, True)

    def arena(self, game, t, reduced):
        self.screen.blit(self.grid, (BOARD_X, BOARD_Y))
        pg.draw.rect(self.screen, (51, 91, 111), (BOARD_X-2, BOARD_Y-2, COLS*CELL+4, ROWS*CELL+4), 2, border_radius=4)
        for x, y in game.level.obstacles:
            rect = pg.Rect(BOARD_X+x*CELL+2, BOARD_Y+y*CELL+2, CELL-4, CELL-4)
            pg.draw.rect(self.screen, (40, 42, 65), rect, border_radius=4)
            pg.draw.rect(self.screen, (153, 100, 143), rect, 1, border_radius=4)
            pg.draw.line(self.screen, (91, 63, 94), rect.topleft, rect.bottomright, 2)
        for i, pair in enumerate(game.level.pairs):
            for cell in pair:
                self.ring(cell, PORTAL_COLORS[i], "AB"[i], t, reduced)
        if game.food is not None:
            pos = center(game.food)
            self.effects.glow(self.screen, pos, CYAN, 13)
            radius = 6 if reduced else int(6 + math.sin(t*5))
            pg.draw.circle(self.screen, CYAN, pos, radius)
            pg.draw.circle(self.screen, WHITE, (pos[0]-2, pos[1]-2), 2)
        if game.gold is not None:
            x, y = center(game.gold)
            self.effects.glow(self.screen, (x, y), GOLD, 16)
            r = 9 if reduced else 9 + math.sin(t*6)*2
            pg.draw.polygon(self.screen, GOLD, [(x, y-r), (x+r, y), (x, y+r), (x-r, y)])
            pg.draw.circle(self.screen, GOLD, (x, y), 13, 1)
        # Only local, explicitly connected history edges are rendered.
        for i, connected in enumerate(game.links):
            if connected:
                a, b = game.body[i], game.body[i+1]
                if abs(a[0]-b[0])+abs(a[1]-b[1]) == 1:
                    pg.draw.line(self.screen, (27, 136, 132), center(a), center(b), CELL-10)
        for i, cell in reversed(list(enumerate(game.body))):
            x, y = center(cell)
            color = CYAN if i == 0 else (29, max(120, 207-i*2), max(124, 180-i))
            if i == 0:
                self.effects.glow(self.screen, (x, y), CYAN, 14)
            rect = pg.Rect(x-11, y-11, 22, 22)
            pg.draw.rect(self.screen, color, rect, border_radius=6)
            if i == 0:
                dx, dy = game.direction
                for side in (-1, 1):
                    eye = (x+dx*5+dy*side*5, y+dy*5+dx*side*5)
                    pg.draw.circle(self.screen, BG, eye, 2)
        preview = game.preview()
        if preview:
            target, danger, d = preview
            x, y = center(target)
            color = PINK if danger else WHITE
            pg.draw.rect(self.screen, color, (x-18, y-18, 36, 36), 2, border_radius=7)
            end = (x+d[0]*27, y+d[1]*27)
            pg.draw.line(self.screen, color, (x+d[0]*14, y+d[1]*14), end, 3)
            pg.draw.polygon(self.screen, color, [end, (end[0]-d[0]*8+d[1]*5, end[1]-d[1]*8+d[0]*5),
                                                   (end[0]-d[0]*8-d[1]*5, end[1]-d[1]*8-d[0]*5)])
        self.effects.draw(self.screen)

    def game(self, game, high, t, reduced, hint):
        self.base()
        self.text(f"0{game.index+1}  /  {game.level.name.upper()}", (80, 90), 24)
        self.text(f"SCORE  {game.score:04}    BEST  {high:04}", (545, 92), 20, CYAN)
        self.text(f"ENERGY  {game.collected:02} / {game.level.goal:02}     |     {game.speed:.1f} CELLS / S", (80, 124), 14, MUTED)
        if game.gold is not None:
            self.text(f"GOLD  {game.gold_left:.1f}s", (775, 124), 14, GOLD)
        self.arena(game, t, reduced)
        self.text(hint, (80, 734), 16, MUTED)
        self.text("A / B  PAIRED EXITS", (740, 734), 14, PORTAL_COLORS[0])

    def menu(self, title, subtitle, lines, options, selected, hint, t, compact=False):
        self.base()
        # Quiet orbital illustration gives menus a shared visual identity.
        for i, color in enumerate(PORTAL_COLORS):
            x, y = 880-i*760, 230+i*340
            self.effects.glow(self.screen, (x, y), color, 40)
            pg.draw.circle(self.screen, color, (x, y), 46, 1)
            pg.draw.circle(self.screen, (39, 48, 70), (x, y), 62, 1)
        self.text(title, (500, 125), 36 if compact else 48, WHITE, True, 860)
        self.text(subtitle, (500, 175), 16, CYAN, True, 850)
        for i, line in enumerate(lines):
            self.text(line, (500, 224+i*29), 18, MUTED, True, 820)
        row = 40 if compact else 52
        start = 210 if compact else max(300, 240+len(lines)*29)
        self.buttons = []
        for i, option in enumerate(options):
            rect = pg.Rect(235, start+i*row, 530, row-8)
            chosen = i == selected
            pg.draw.rect(self.screen, (20, 49, 61) if chosen else (13, 25, 41), rect, border_radius=7)
            pg.draw.rect(self.screen, CYAN if chosen else (37, 53, 73), rect, 2 if chosen else 1, border_radius=7)
            if chosen:
                pg.draw.rect(self.screen, CYAN, (rect.x+1, rect.y+10, 3, rect.h-20), border_radius=2)
            self.text(option, rect.center, 18 if compact else 20, WHITE if chosen else MUTED, True, 480)
            self.buttons.append(rect)
        self.text(hint, (500, 726), 16, MUTED, True, 920)

