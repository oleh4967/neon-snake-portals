"""Neon Snake: Portals — procedural desktop arcade."""
