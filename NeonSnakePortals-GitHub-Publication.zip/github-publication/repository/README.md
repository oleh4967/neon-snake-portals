# Neon Snake: Portals

A neon-styled Snake arcade game with paired portals, five handcrafted arenas,
golden energy bonuses, and keyboard, mouse, and gamepad support.

![Neon Snake: Portals — Interweave arena](docs/screenshots/arena.png)

## Download and play

Open this repository's **Releases** section and download
**`NeonSnakePortals-1.0.0-Windows-x64.zip`**.

1. Extract the **entire** archive to a folder on your computer.
2. Double-click **`NeonSnakePortals.exe`**.
3. Select **Start campaign**, then **Enter arena**.

**Python is not required for the portable Windows release.** Keep the `_internal`
folder next to the executable. To add a desktop icon, double-click
`CreateDesktopShortcut.cmd` after moving the game to its final location.

The portable release targets **Windows 10/11 x64** and has been tested on
Windows 11. Windows 10 and other computers have not yet been tested. Native
macOS, Linux, and Windows ARM releases are not included. The build is unsigned.

GitHub's automatically generated **Source code** archives contain the project
sources, not the ready-to-play Windows application.

## Features

- Five arenas: Awakening, First Crossing, Contours, Interweave, and Neon Core.
- A 30 × 20 grid, independent rendering and movement rates, and a two-turn buffer.
- Paired portals labeled **A** and **B**, with preserved direction and exit previews.
- Cyan energy spheres, timed golden diamonds, growth, and campaign scoring.
- Procedural neon graphics, cached glows, particles, and synthesized sound effects.
- Keyboard and mouse menus, SDL controller mappings, hotplug handling, and a
  fallback control-assignment screen for unrecognized gamepads.
- Volume, mute, reduced effects, stick dead zone, and active-controller settings.
- Local high scores and unlocked arenas saved outside the game folder.
- Automatic pause on focus loss or active-controller disconnection.

## Controls

| Action | Keyboard / mouse | Standard SDL gamepad |
|---|---|---|
| Steer / navigate menus | Arrow keys or WASD | D-pad or left stick |
| Confirm / start | Enter, Num Enter, or click | A, bottom face button |
| Back / pause during play | Escape | B, right face button |
| Pause / resume | Space or P | Start / Menu |
| Retry after defeat | R | X, left face button |
| Adjust a setting | Left / Right; click cycles forward | D-pad Left / Right |

The snake moves automatically. Reversing directly into your body is prohibited.
Fast turns are checked against the last accepted buffered direction.

For gamepads, Settings offers **D-pad**, **Left stick**, or **Both**. The initial
stick dead zone is **0.25**. D-pad input takes priority in Both mode. Unrecognized
devices can be configured through **Assign fallback controls**. Home and Turbo
are not assigned by the game. Keyboard and mouse input remain available.

For the 8BitDo Ultimate 2C Wireless on Windows, use USB or its supplied 2.4 GHz
receiver. Hardware-specific compatibility still requires testing on your device.
See [8BitDo's official product information](https://www.8bitdo.com/ultimate-2c-wireless-controller/).

## Rules

Ordinary spheres give **10 points** and golden diamonds give **50 points**.
Both grow the snake by one cell. Only ordinary spheres count toward a level's
goal. A golden diamond can appear after every fourth ordinary collection and
expires after eight seconds of active game time.

Portals teleport the head directly onto the paired portal cell, preserving its
direction. Only one teleport occurs per step. The body follows the head's cell
history without a line drawn across the arena. The next exit is highlighted;
an unsafe exit receives a warning outline.

Walls, obstacles, and your own body end the attempt. Moving into the departing
tail cell is allowed when the snake is not growing. When no eligible reachable
food cell remains, the reachable arena is considered secured and the level clears.

Each new level starts with a fresh four-cell snake. Campaign score carries
forward, while retrying restores the score from the start of that level.

| Arena | Ordinary sphere goal | Initial speed | Portal pairs |
|---|---:|---:|---:|
| Awakening | 5 | 7.0 cells/s | 0 |
| First Crossing | 6 | 7.5 cells/s | 1 |
| Contours | 7 | 8.0 cells/s | 1 |
| Interweave | 8 | 8.5 cells/s | 2 |
| Neon Core | 10 | 9.0 cells/s | 2 |

## Run from source

Verified development environment: **CPython 3.14.7**, **pygame-ce 2.5.8**,
**SDL 2.32.10**, Windows x64. The dependency is named `pygame-ce` on PyPI and
is imported as `pygame`. Use a separate environment rather than installing
`pygame` and `pygame-ce` together.

From the repository root, in PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe main.py
```

After setup, `run_windows.bat` also launches the source version.
On Linux/macOS, use `.venv/bin/python` instead; those platforms have not been
tested. No downloaded images, sounds, or fonts are needed for the first run.
The game uses available system fonts, with a packaged Pygame font as fallback.

## Tests

```powershell
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The latest local run passed **53 tests**, including a complete seeded campaign
that collects all 36 ordinary spheres without changing the game rules or goals.
Rules can be tested without a window. UI integration checks use SDL dummy
devices, and save tests use temporary directories.

The portable EXE was also tested after relocation to a path containing spaces
and Cyrillic, with external Python paths cleared. Startup, rendering, audio
failure, save reload, and desktop-shortcut creation passed. This is not a claim
of testing on a separate clean PC. See [verification notes](docs/TESTING.md).

## Build a Windows release

Build on Windows using Python 3.14.7:

```powershell
python -m venv .build-venv
.build-venv\Scripts\python.exe -m pip install -r requirements-build.txt
.build-venv\Scripts\python.exe build_windows.py --pygame-source C:\path\to\pygame_ce-2.5.8.tar.gz
```

The unmodified pygame-ce source archive is included in the portable release
under `licenses/source/` and can also be downloaded from the
[pygame-ce 2.5.8 PyPI page](https://pypi.org/project/pygame-ce/2.5.8/).
Replace the example source-archive path with its actual location.

The script creates `dist/NeonSnakePortals` using PyInstaller's onedir/windowed
mode without UPX. It includes the runtime, notices, original game sources, and
the desktop-shortcut helper. Distribute the complete directory as a ZIP.

## Project layout

```text
main.py                    Entry point
launch.pyw                 Windowed launcher and startup-error reporting
neon_snake/settings.py     Named constants
neon_snake/logic.py        Pure grid rules and campaign progression
neon_snake/levels.py       Five arenas and geometry validation
neon_snake/app.py          Screens, events, and application loop
neon_snake/input.py        SDL/fallback controllers and stick filtering
neon_snake/ui.py           Rendering and cached fonts/backgrounds
neon_snake/effects.py      Cached glows and bounded particles
neon_snake/audio.py        Synthesized PCM sound effects
neon_snake/saves.py        Validated JSON and atomic writes
neon_snake/shortcut.py     Windows Unicode desktop shortcuts
tests/                    Rule and integration tests
distribution/             Portable-release documentation and helper
build_windows.py          Windows packaging script
```

## Saves and troubleshooting

On Windows, settings and progress are stored in:

```text
%LOCALAPPDATA%\NeonSnakePortals\save.json
```

Startup errors from the windowed launcher are written to:

```text
%LOCALAPPDATA%\NeonSnakePortals\launch-error.log
```

Missing saves use defaults. Invalid JSON and invalid settings are recovered
with validated defaults. Save failures are reported without stopping gameplay.
An unfinished attempt is not resumed after restarting the game.

If the portable game does not start, extract the complete archive and check
that `_internal` is next to the EXE. When reporting a problem, include your
Windows version, game version, reproduction steps, and any error message.
Review logs before posting them publicly because they may contain local paths.

## License

Original game code and procedural game assets are provided under the
[MIT License](LICENSE.txt). Python, pygame-ce, SDL, and other bundled components
retain their respective licenses. Their notices are included with the portable
release. System fonts are used when available and are not redistributed.
