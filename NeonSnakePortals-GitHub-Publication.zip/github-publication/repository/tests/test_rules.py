import json
import random
import tempfile
import unittest
from pathlib import Path

from neon_snake.logic import Game, Campaign, add
from neon_snake.levels import Level, LEVELS, validate_levels
from neon_snake.settings import *
from neon_snake.input import StickFilter, PadEdges
from neon_snake.saves import Store, clean

class Rules(unittest.TestCase):
    def game(self, **kwargs):
        g = Game(rng=random.Random(10), **kwargs)
        g.food = (25, 18)
        return g

    def test_movement(self):
        g = self.game()
        g.step()
        self.assertEqual(g.body, [(8,10),(7,10),(6,10),(5,10)])

    def test_normal_growth_score(self):
        g = self.game()
        g.food = (8,10)
        g.step()
        self.assertEqual((len(g.body),g.score,g.collected), (5,10,1))
        self.assertNotIn(g.food, g.body)

    def test_gold_growth_not_goal(self):
        g = self.game()
        g.gold, g.gold_left = (8,10), 5
        g.step()
        self.assertEqual((len(g.body),g.score,g.collected), (5,50,0))
        self.assertIsNone(g.gold)

    def test_reverse(self):
        g = self.game()
        self.assertFalse(g.queue(LEFT))
        self.assertEqual(g.direction, RIGHT)

    def test_buffer_validates_last_accepted(self):
        g = self.game()
        self.assertTrue(g.queue(UP))
        self.assertFalse(g.queue(DOWN))
        self.assertTrue(g.queue(LEFT))
        self.assertFalse(g.queue(DOWN))  # full
        g.step()
        self.assertEqual(g.body[0], (7,9))
        g.step()
        self.assertEqual(g.body[0], (6,9))

    def test_repeat_direction_does_not_fill_buffer(self):
        g = self.game()
        for _ in range(20): g.queue(UP)
        self.assertEqual(list(g.turns), [UP])

    def test_tail_departure(self):
        g = self.game()
        g.body = [(5,5),(5,6),(4,6),(4,5)]
        g.direction = LEFT
        g.step()
        self.assertEqual(g.state,"playing")
        self.assertEqual(g.body[0], (4,5))

    def test_tail_not_vacated_when_growing(self):
        g = self.game()
        g.body = [(5,5),(5,6),(4,6),(4,5)]
        g.direction, g.food = LEFT, (4,5)
        g.step()
        self.assertEqual(g.reason,"Own body")

    def test_wall(self):
        g = self.game()
        g.body[0] = (29,10)
        g.step()
        self.assertEqual((g.state,g.reason), ("dead","Wall"))

    def test_obstacle(self):
        g = self.game(level=Level("test", 5, 7, frozenset({(8,10)})))
        g.step()
        self.assertEqual(g.reason, "Obstacle")

    def test_body_collision(self):
        g = self.game()
        g.body = [(5,5),(6,5),(6,6),(5,6)]
        g.step()
        self.assertEqual(g.reason,"Own body")

    def test_all_portals_both_ways_all_directions(self):
        for index, level in enumerate(LEVELS):
            for entry, target in level.portals.items():
                for d in DIRECTIONS.values():
                    with self.subTest(level=index, entry=entry, direction=d):
                        g = self.game(index=index)
                        g.body = [(entry[0]-d[0]*k,entry[1]-d[1]*k) for k in range(1,5)]
                        g.direction = d
                        g.step()
                        self.assertEqual(g.body[0],target)
                        self.assertEqual(g.direction,d)
                        self.assertFalse(g.links[0])
                        g.step()
                        self.assertEqual(g.body[0], add(target,d))

    def test_exit_body_collision_preview(self):
        g = self.game(index=1)
        g.body = [(7,5),(22,14),(21,14),(20,14)]
        self.assertTrue(g.preview()[1])
        g.step()
        self.assertEqual(g.reason,"Own body")

    def test_portal_exit_vacating_tail(self):
        g = self.game(index=1)
        g.body = [(7,5),(6,5),(5,5),(22,14)]
        self.assertFalse(g.preview()[1])
        g.step()
        self.assertEqual(g.body[0], (22,14))
        self.assertEqual(g.state,"playing")

    def test_body_follows_history_without_long_link(self):
        g = self.game(index=1)
        g.body = [(7,5),(6,5),(5,5),(4,5)]
        g.step()
        for _ in range(3):
            for i, link in enumerate(g.links):
                if link:
                    a,b = g.body[i:i+2]
                    self.assertEqual(abs(a[0]-b[0])+abs(a[1]-b[1]),1)
            g.step()
        self.assertTrue(all(g.links))

    def test_portal_gold_collision_uses_growing_body(self):
        g = self.game(index=1)
        g.body = [(7,5),(6,5),(5,5),(22,14)]
        g.gold = (22,14)
        g.step()
        self.assertEqual(g.reason,"Own body")

    def test_food_free_reachable_all_levels(self):
        for index in range(5):
            g = self.game(index=index)
            for _ in range(20):
                g.food = None
                available = g.free_cells()
                g.spawn_food()
                self.assertIn(g.food,available)
                self.assertNotIn(g.food,set(g.body)|g.level.obstacles|set(g.level.portals))

    def test_food_excludes_gold(self):
        g = self.game()
        g.gold = (15,10)
        self.assertNotIn(g.gold,g.free_cells())

    def test_no_free_cells_finite_clear(self):
        occupied = frozenset((x,y) for x in range(COLS) for y in range(ROWS) if (x,y) not in LEVELS[0].start)
        g = Game(level=Level("full",5,7,occupied))
        self.assertEqual(g.state,"complete")
        self.assertIsNone(g.food)

    def test_gold_spawn_period_and_expiry(self):
        g = self.game()
        g.collected = 3
        g.food = (8,10)
        g.step()
        self.assertIsNotNone(g.gold)
        self.assertNotEqual(g.gold,g.food)
        g.gold_left = .05
        score = g.score
        g.update(.06)
        self.assertIsNone(g.gold)
        self.assertEqual(g.score,score)

    def test_pause_stops_all_timers(self):
        g = self.game()
        g.gold,g.gold_left = (15,10),4
        g.queue(UP)
        g.set_paused(True)
        before = (list(g.body),g.gold_left,g.elapsed)
        g.update(10)
        g.step()
        self.assertEqual((g.body,g.gold_left,g.elapsed),before)
        self.assertFalse(g.turns)
        g.set_paused(False)
        g.update(.01)
        self.assertEqual(g.body,before[0])

    def test_no_stall_catchup(self):
        g = self.game(index=4)
        g.update(60)
        self.assertLessEqual(g.body[0][0],8)
        self.assertLessEqual(g.elapsed,.1)

    def test_goal_completes_current_step(self):
        g = self.game()
        g.collected = g.level.goal-1
        g.food = (8,10)
        g.step()
        self.assertEqual((g.state,g.body[0],len(g.body)),("complete",(8,10),5))

    def test_retry_rolls_back(self):
        c = Campaign()
        c.game.start_score = 120
        c.game.score = 200
        c.retry()
        self.assertEqual((c.game.score,c.game.start_score,len(c.game.body)),(120,120,4))

    def test_campaign_five_levels(self):
        c = Campaign(rng=random.Random(8))
        for index in range(5):
            g = c.game
            self.assertEqual(g.index,index)
            g.collected = g.level.goal-1
            g.food = (8,10)
            g.step()
            self.assertEqual(g.state,"complete")
            score = g.score
            c.next_level()
            self.assertEqual(c.game.score,score)
            if index < 4:
                self.assertEqual(len(c.game.body),4)
                self.assertEqual(c.game.collected,0)
        self.assertTrue(c.won)

    def test_speed_capped(self):
        g = self.game(index=4)
        g.collected = 500
        self.assertEqual(g.speed,MAX_SPEED)

    def test_level_geometry(self):
        validate_levels()

class InputRules(unittest.TestCase):
    def test_deadzone_and_hysteresis(self):
        f = StickFilter()
        self.assertIsNone(f.read(.24,0,.25))
        self.assertEqual(f.read(.3,0,.25),"right")
        self.assertEqual(f.read(.21,0,.25),"right")
        self.assertIsNone(f.read(.1,0,.25))

    def test_diagonal_axis_tie(self):
        f = StickFilter()
        self.assertEqual(f.read(.8,.8,.25),"right")
        self.assertEqual(f.read(.1,.9,.25),"down")
        self.assertEqual(f.read(.8,.8,.25),"down")

    def test_stick_hold_and_reengage(self):
        e = PadEdges()
        e.update(None,set(),True,0,False)
        self.assertEqual(e.update("up",set(),False,.1,False),["up"])
        self.assertEqual(e.update("up",set(),False,10,False),[])
        e.update(None,set(),True,11,False)
        self.assertEqual(e.update("up",set(),False,12,False),["up"])

    def test_menu_repeat(self):
        e = PadEdges()
        e.update(None,set(),True,0,True)
        self.assertEqual(e.update("down",set(),False,.1,True),["down"])
        self.assertEqual(e.update("down",set(),False,.44,True),[])
        self.assertEqual(e.update("down",set(),False,.46,True),["down"])
        self.assertEqual(e.update("down",set(),False,.62,True),["down"])

    def test_confirmation_edge_only(self):
        e = PadEdges()
        e.update(None,set(),True,0,True)
        self.assertEqual(e.update(None,{"a"},False,1,True),["a"])
        self.assertEqual(e.update(None,{"a"},False,2,True),[])

    def test_reconnect_requires_neutral(self):
        e = PadEdges()
        self.assertEqual(e.update("right",{"a"},False,0,True),[])
        self.assertEqual(e.update(None,set(),True,1,True),[])
        self.assertEqual(e.update(None,{"a"},False,2,True),["a"])

class Saves(unittest.TestCase):
    def test_missing_created_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/"user"/"save.json"
            s = Store(p)
            self.assertTrue(p.exists())
            s.data.update(high_score=400,unlocked=4,deadzone=.35,control_mode="D-pad")
            self.assertTrue(s.write())
            self.assertEqual(Store(p).data,s.data)
            self.assertEqual(list(p.parent.glob("*.tmp")),[])

    def test_corrupt_recovery(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/"save.json"
            p.write_text("{broken",encoding="utf-8")
            s = Store(p)
            self.assertEqual(s.data["high_score"],0)
            self.assertTrue(s.warning)
            self.assertIsInstance(json.loads(p.read_text()),dict)

    def test_type_range_validation(self):
        s = clean(dict(high_score=True,unlocked=99,volume="loud",deadzone=-3,muted=1,
                       reduced_effects="no",control_mode="invalid",bindings={"a":{"up":["button",-1,1]}}))
        self.assertEqual((s["high_score"],s["unlocked"],s["volume"],s["deadzone"],s["muted"]),(0,5,.55,.1,False))
        self.assertEqual(s["bindings"],{"a":{}})
        self.assertEqual(clean([])["unlocked"],1)
        self.assertEqual(clean({"volume":float("nan")})["volume"],.55)

    def test_unwritable_save_graceful(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/"file"
            p.write_text("occupied")
            s = Store(p/"save.json")
            self.assertFalse(s.write())
            self.assertTrue(s.warning)

if __name__ == "__main__":
    unittest.main()
