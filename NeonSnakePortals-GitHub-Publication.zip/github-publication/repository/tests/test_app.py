"""Integration checks use SDL dummy devices, never a real user save."""
import os
os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
import pygame as pg
from neon_snake.app import App, DISCONNECTED
from neon_snake.audio import Audio
from neon_snake.input import Pads
from neon_snake.saves import clean, Store

class Integration(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = App(Path(self.tmp.name)/"save.json")
        pg.event.clear()

    def tearDown(self):
        pg.quit()
        self.tmp.cleanup()

    def test_all_screens_render(self):
        a = self.app
        for state in ("main","tutorial","ready","playing","pause","settings","levels","results","dead","victory","mapping"):
            with self.subTest(screen=state):
                a.state = state
                a.draw()
                pg.display.flip()
                for rect in a.view.buttons:
                    self.assertTrue(a.screen.get_rect().contains(rect))

    def test_focus_loss_pauses_no_auto_resume(self):
        a = self.app
        a.resume()
        pg.event.post(pg.event.Event(pg.WINDOWFOCUSLOST))
        a.events()
        self.assertEqual(a.state,"pause")
        self.assertTrue(a.game.paused)
        pg.event.post(pg.event.Event(pg.WINDOWFOCUSGAINED))
        a.events()
        self.assertEqual(a.state,"pause")

    def test_one_press_does_not_start_two_screens(self):
        a = self.app
        for _ in range(2): pg.event.post(pg.event.Event(pg.KEYDOWN,key=pg.K_RETURN))
        a.events()
        self.assertEqual(a.state,"ready")

    def test_keyboard_and_mouse_menu(self):
        a = self.app
        a.draw()
        pg.event.post(pg.event.Event(pg.MOUSEBUTTONDOWN,button=1,pos=a.view.buttons[2].center))
        a.events()
        self.assertEqual(a.state,"tutorial")
        a.action("b")
        a.action("down")
        a.action("a")
        self.assertEqual(a.state,"levels")

    def test_disconnect_pause(self):
        a = self.app
        a.resume()
        with patch.object(a.pads,"refresh",return_value=True):
            pg.event.post(pg.event.Event(pg.JOYDEVICEREMOVED,instance_id=123))
            a.events()
        self.assertEqual(a.state,"pause")
        self.assertEqual(a.message,DISCONNECTED)
        a.draw()

    def test_no_audio_device(self):
        with patch.object(pg.mixer,"init",side_effect=pg.error("No audio device")):
            audio = Audio(clean({}))
            audio.play("food")
            self.assertEqual(audio.sounds,{})

    def test_record_unlock_and_retry_saved(self):
        a = self.app
        a.resume()
        a.game.score = 60
        a.game.state = "complete"
        a.update(.01)
        self.assertEqual(a.state,"results")
        self.assertEqual(a.settings["high_score"],60)
        self.assertEqual(a.settings["unlocked"],2)
        a.action("a")
        self.assertEqual(a.game.start_score,60)
        a.resume()
        a.game.score = 90
        a.game.state = "dead"
        a.update(.01)
        a.action("x")
        self.assertEqual(a.game.score,60)

    def test_dpad_priority_and_modes_with_standard_mapping(self):
        class Joy:
            def get_numbuttons(self): return 0
        class Ctrl:
            def get_button(self,code): return code == pg.CONTROLLER_BUTTON_DPAD_UP
            def get_axis(self,code): return 32767 if code == pg.CONTROLLER_AXIS_LEFTX else 0
        p = self.app.pads
        p.devices = {1:dict(joy=Joy(),ctrl=Ctrl(),guid="fake",name="test")}
        p.active = 1
        p.edges.armed = True
        self.assertEqual(p.poll(0,False),["up"])
        p.settings["control_mode"] = "Left stick"
        p.reset()
        p.edges.armed = True
        self.assertEqual(p.poll(1,False),["right"])

    def test_cyrillic_font_metrics(self):
        font = self.app.view.fonts[18]
        metrics = font.metrics(DISCONNECTED)
        self.assertTrue(all(metric is not None for char,metric in zip(DISCONNECTED,metrics) if char != " "))

    def test_keypad_enter(self):
        pg.event.post(pg.event.Event(pg.KEYDOWN,key=pg.K_KP_ENTER))
        self.app.events()
        self.assertEqual(self.app.state,"ready")

    def test_record_survives_reload(self):
        a = self.app
        a.resume()
        a.game.score = 270
        a.game.state = "dead"
        a.update(.01)
        self.assertEqual(Store(a.store.path).data["high_score"],270)

    def test_custom_assignment_persists(self):
        a = self.app
        a.pads.devices = {44:dict(joy=None,ctrl=None,guid="unknown-guid",name="Generic pad")}
        a.pads.active = 44
        event = pg.event.Event(pg.JOYBUTTONDOWN,instance_id=44,button=9)
        self.assertEqual(a.pads.capture(event,"a"),["button",9,1])
        event = pg.event.Event(pg.JOYAXISMOTION,instance_id=44,axis=3,value=-.9)
        self.assertEqual(a.pads.capture(event,"axis_x"),["axis",3,-1])
        a.settings["bindings"] = {"unknown-guid":{"a":["button",9,1],"axis_x":["axis",3,-1]}}
        a.store.write()
        self.assertEqual(Store(a.store.path).data["bindings"],a.settings["bindings"])

    def test_controller_selection(self):
        p = self.app.pads
        p.devices = {12:dict(joy=None,ctrl=None,guid="one",name="Same name"),
                     24:dict(joy=None,ctrl=None,guid="two",name="Same name")}
        p.active = 12
        p.select(1)
        self.assertEqual(p.active,24)
        self.assertIn("[2/2]",p.label)
        self.assertEqual(p.settings["active_guid"],"two")

if __name__ == "__main__": unittest.main()
