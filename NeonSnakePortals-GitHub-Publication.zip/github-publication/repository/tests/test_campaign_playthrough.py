"""A real seeded run: route to spawned food without changing any game rules."""
from collections import deque
import random
import unittest
from neon_snake.logic import Campaign, add
from neon_snake.settings import COLS, ROWS, DIRECTIONS

def route_to_food(game):
    origin = (game.body[0], game.direction)
    todo = deque([(origin, None)])
    seen = {origin}
    blocked = set(game.body) | game.level.obstacles
    while todo:
        (pos, direction), first = todo.popleft()
        for d in DIRECTIONS.values():
            if d == (-direction[0], -direction[1]):
                continue
            entry = add(pos, d)
            target = game.level.portals.get(entry, entry)
            if (not (0 <= target[0] < COLS and 0 <= target[1] < ROWS) or
                    entry in blocked or target in blocked):
                continue
            next_state = (target, d)
            command = first or d
            if target == game.food:
                return command
            if next_state not in seen:
                seen.add(next_state)
                todo.append((next_state, command))
    return None

class CampaignPlaythrough(unittest.TestCase):
    def test_full_seeded_campaign_without_state_shortcuts(self):
        campaign = Campaign(rng=random.Random(42))
        count, teleports, ordinary = 0, 0, 0
        while not campaign.won and count < 6000:
            g = campaign.game
            if g.state == "complete":
                ordinary += g.collected
                campaign.next_level()
                continue
            self.assertEqual(g.state,"playing",(g.index,g.reason))
            command = route_to_food(g)
            self.assertIsNotNone(command, f"No conservative route at level {g.index+1}")
            g.queue(command)
            head = g.body[0]
            while g.state == "playing" and g.body[0] == head:
                g.update(.025)
            teleports += sum(name == "portal" for name, _ in g.events)//2
            g.events.clear()
            count += 1
        self.assertTrue(campaign.won)
        self.assertEqual(ordinary,36)
        self.assertGreater(teleports,0)
        self.assertGreaterEqual(campaign.game.score,360)

if __name__ == "__main__": unittest.main()
