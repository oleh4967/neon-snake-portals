import ctypes as ct
from pathlib import Path
import sys
import tempfile
import unittest
from neon_snake.shortcut import create_shortcut

@unittest.skipUnless(sys.platform == "win32", "Windows Shell Links only")
class Shortcuts(unittest.TestCase):
    def test_unicode_game_and_destination_paths(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)/"Игры с пробелами"
            root.mkdir()
            executable = root/"NeonSnakePortals.exe"
            executable.write_bytes(b"test target")
            desktop = root/"Рабочий стол"
            desktop.mkdir()
            link = create_shortcut(executable, desktop)
            self.assertTrue(link.is_file())
            self.assertIn(str(executable).encode("utf-16-le"),link.read_bytes())

    def test_missing_executable_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(FileNotFoundError):
                create_shortcut(Path(folder)/"absent.exe", folder)

if __name__ == "__main__": unittest.main()
