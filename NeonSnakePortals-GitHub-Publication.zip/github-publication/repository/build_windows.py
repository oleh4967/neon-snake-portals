"""Build an onedir Windows release. Run with the locked build environment."""
import argparse
import importlib.metadata
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent

def source_zip(target):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(ROOT.rglob("*")):
            relative = file.relative_to(ROOT)
            if not file.is_file() or any(part in {".venv", ".build-venv", "__pycache__", "dist", "build", "work", ".git"} for part in relative.parts):
                continue
            if file.suffix.lower() in {".lnk", ".pyc", ".pyo", ".zip"}:
                continue
            archive.write(file, Path("neon_snake")/relative)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dist-dir", type=Path, default=ROOT/"dist")
    parser.add_argument("--work-dir", type=Path, default=ROOT/"build")
    parser.add_argument("--pygame-source", type=Path, required=True,
                        help="Official pygame_ce-2.5.8.tar.gz source from PyPI")
    args = parser.parse_args()
    if sys.platform != "win32":
        parser.error("This script creates a Windows release; run it on Windows.")
    if not args.pygame_source.is_file():
        parser.error("pygame source archive does not exist")
    dist, work = args.dist_dir.resolve(), args.work_dir.resolve()
    work.mkdir(parents=True, exist_ok=True)
    subprocess.run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--onedir", "--windowed", "--noupx",
                    "--name", "NeonSnakePortals", "--icon", str(ROOT/"neon_snake.ico"),
                    "--hidden-import", "pygame._sdl2.controller", "--distpath", str(dist),
                    "--workpath", str(work/"cache"), "--specpath", str(work), str(ROOT/"launch.pyw")], check=True)
    release = dist/"NeonSnakePortals"
    for name, destination in (("PLAY.txt", "README.txt"), ("CreateDesktopShortcut.cmd", "CreateDesktopShortcut.cmd"),
                              ("THIRD_PARTY.txt", "THIRD_PARTY.txt")):
        shutil.copy2(ROOT/"distribution"/name, release/destination)
    shutil.copy2(ROOT/"LICENSE.txt", release/"LICENSE.txt")
    licenses = release/"licenses"
    licenses.mkdir(exist_ok=True)
    python_root = Path(sys.base_prefix)
    shutil.copy2(python_root/"LICENSE.txt", licenses/"Python-LICENSE.txt")
    import pygame
    pygame_dir = Path(pygame.__file__).parent
    shutil.copy2(pygame_dir/"docs"/"generated"/"LGPL.txt", licenses/"pygame-LGPL.txt")
    pyinstaller = importlib.metadata.distribution("pyinstaller")
    copying = next(p for p in pyinstaller.files if str(p).endswith("licenses/COPYING.txt"))
    shutil.copy2(pyinstaller.locate_file(copying), licenses/"PyInstaller-COPYING.txt")
    dependencies = licenses/"pygame-dependencies"
    dependencies.mkdir(exist_ok=True)
    with tarfile.open(args.pygame_source) as archive:
        for member in archive.getmembers():
            if member.isfile() and "/docs/licenses/" in member.name and member.name.endswith(".txt"):
                # Only copy flat text notices, never extract arbitrary archive paths.
                data = archive.extractfile(member).read()
                (dependencies/Path(member.name).name).write_bytes(data)
    bundled_source = licenses/"source"
    bundled_source.mkdir(exist_ok=True)
    shutil.copy2(args.pygame_source, bundled_source/args.pygame_source.name)
    game_source = release/"source"
    game_source.mkdir(exist_ok=True)
    source_zip(game_source/"NeonSnakePortals-source.zip")
    print("Release prepared:", release)
    print("Zip the whole directory after verifying the EXE.")

if __name__ == "__main__":
    main()
