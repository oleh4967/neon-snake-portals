# Verification notes

Last tested: November 1, 2026.

Environment: Windows 11 x64, CPython 3.14.7, pygame-ce 2.5.8, SDL 2.32.10.
Packager: PyInstaller 6.22.3 with hooks-contrib 2026.9.

## Automated source tests

All **53 tests passed**. They cover movement, growth, buffered turns, departing
tail cells, all collision types, every portal pair in both directions, preserved
direction, single-step teleport behavior, body history, reachable food placement,
full arenas, golden bonus timing, pause behavior, speed caps, campaign transitions,
retry scoring, save recovery and reload, and audio-initialization failure.

Input tests cover dead zones, hysteresis, diagonal-axis selection, held inputs,
menu repeat, button edges, neutral gating, D-pad priority, active-controller
selection, custom mappings, focus loss, disconnect pause, and screen transitions.
Device-level controller behavior is simulated in these checks.

A seeded playthrough collects all 36 ordinary spheres across five arenas,
uses portals, and reaches victory without changing food positions or goals.
Windows shortcut tests cover paths with spaces and Cyrillic characters.

## Portable executable checks

The release ZIP was extracted to another directory containing spaces and
Cyrillic characters. The EXE was launched from an unrelated working directory
with PYTHONHOME/PYTHONPATH cleared and PATH reduced to Windows System32.

Menu, portal showcase, Cyrillic message, and unavailable-audio-driver scenarios
all completed with exit code 0. Each generated a rendered frame and valid save.
A restart displayed a seeded record and unlocked-level count from that save.
Process modules confirmed Python and SDL loaded from the bundled `_internal`
directory. The actual desktop-shortcut helper created a link in a test folder.

## Visual checks and limits

The source application was inspected in a real window: menus, selection,
mouse navigation, active movement, wall defeat, and the full Cyrillic disconnect
message. Rendered frames of the portable EXE's menu and portal arena were also
visually inspected.

The portable build was not tested on a separate clean PC. Windows 10, macOS,
Linux, Windows ARM, physical controller hotplug, and specific 8BitDo hardware
remain unverified. A complete human-controlled campaign was not performed.
Source-rule playthrough tests and EXE startup checks are separate evidence.
