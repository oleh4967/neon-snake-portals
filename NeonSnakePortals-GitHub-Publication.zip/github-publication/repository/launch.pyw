"""Windowed Windows entry point; .pyw avoids opening a console."""
import ctypes
import os
import sys
from pathlib import Path
import traceback

if __name__ == "__main__":
    try:
        if "--create-shortcut" in sys.argv[1:]:
            from neon_snake.shortcut import create_shortcut
            if not getattr(sys, "frozen", False):
                raise RuntimeError("Use the portable EXE to create a standalone shortcut.")
            create_shortcut(sys.executable, os.environ.get("NEON_SHORTCUT_DIR"))
        else:
            from neon_snake.app import main
            main()
    except Exception:
        detail = traceback.format_exc()
        log = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "NeonSnakePortals" / "launch-error.log"
        try:
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text(detail, encoding="utf-8")
            message = f"Could not start Neon Snake: Portals.\nDetails: {log}"
        except OSError:
            message = "Could not start Neon Snake: Portals.\n" + detail[-1800:]
        ctypes.windll.user32.MessageBoxW(None, message, "Neon Snake: Portals", 0x10)
        raise SystemExit(1)
