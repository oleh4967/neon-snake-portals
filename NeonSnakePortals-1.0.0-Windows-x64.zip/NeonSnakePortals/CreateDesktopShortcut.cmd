@echo off
setlocal
"%~dp0NeonSnakePortals.exe" --create-shortcut
set "NEON_SHORTCUT_EXIT=%ERRORLEVEL%"
if errorlevel 1 echo Could not create shortcut. You can open NeonSnakePortals.exe directly.
if "%NEON_SHORTCUT_EXIT%"=="0" echo Desktop shortcut created.
pause
exit /b %NEON_SHORTCUT_EXIT%
