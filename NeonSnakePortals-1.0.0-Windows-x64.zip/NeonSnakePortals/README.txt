NEON SNAKE: PORTALS 1.0.0 — Windows x64 portable edition

QUICK START
1. Extract the entire ZIP to a folder on your computer.
2. Open NeonSnakePortals.exe. Python and Pygame installation is NOT required.
3. Choose Start campaign, then Enter arena.

Keep the _internal folder next to the EXE. Move/copy the whole game folder.
Optional: double-click CreateDesktopShortcut.cmd to create a desktop shortcut.
Keep the game in its final location before creating the shortcut.

CONTROLS
Arrows / WASD: steer and navigate menus.
Enter / Num Enter: confirm. Space / P: pause. Escape: back or pause.
R: retry after defeat. Menus also support a mouse.
Gamepad: D-pad / left stick, A confirm, B back, X retry, Start pause.
Unknown gamepads can be assigned in Settings > Assign fallback controls.

Five levels, paired portals, gold bonuses, synthesized audio, saved records.
Save: %LOCALAPPDATA%\NeonSnakePortals\save.json
Startup errors: %LOCALAPPDATA%\NeonSnakePortals\launch-error.log
No administrator rights, account or network connection is needed to play.
Delete the extracted game folder to remove the game; saves remain separately.

TARGET PLATFORM
Windows 10/11, 64-bit Intel/AMD (x64), graphical desktop.
Built and tested on Windows 11. Windows 10 and other PCs have not been tested.
This is an unsigned community build. No macOS/Linux executable is included.

ПО-РУССКИ
Распакуйте ВЕСЬ ZIP и откройте NeonSnakePortals.exe двойным щелчком.
Python устанавливать не нужно. Папка _internal должна оставаться рядом с EXE.
Для ярлыка на рабочем столе откройте CreateDesktopShortcut.cmd.
Управление: стрелки/WASD, Enter, пробел/P — пауза, Esc — назад, R — повтор.
Геймпад: крестовина/левый стик, A/B/X/Start. Мышь работает в меню.
Запускайте EXE после распаковки, а не непосредственно внутри ZIP.

LICENSES AND SOURCES
Original game code: source/NeonSnakePortals-source.zip (MIT license).
Python, pygame-ce, SDL and related libraries have their own terms: licenses/.
Unmodified pygame-ce 2.5.8 source archive: licenses/source/pygame_ce-2.5.8.tar.gz.
Game files and licenses can be shared together as this complete ZIP.
